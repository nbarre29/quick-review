package demo;

public class Producer implements Runnable {
	
	Inventory inventory;
	public Producer(Inventory inventory) {
		
		this.inventory = inventory;
		//new Thread(this).start();
	}

	@Override
	public void run() {
		
		int x = 1;
		while (true) {
			inventory.put(x++);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
			
		}

	}

}

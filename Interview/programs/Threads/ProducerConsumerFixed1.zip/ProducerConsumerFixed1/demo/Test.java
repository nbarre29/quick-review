package demo;

public class Test {

	public static void main(String[] args) {
		
		Inventory inventory = new Inventory();		
		//new Producer(inventory);
		//new Consumer(inventory);
		new Thread(new Producer(inventory)).start();
		new Thread(new Consumer(inventory)).start();

	}

}

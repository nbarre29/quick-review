package demo;

public class Inventory {
	
	private boolean flag = false;
	private int n;
	
	synchronized void put(int n){
		if (flag) {
			try {
				wait();
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}
		this.n = n;
		System.out.println("PUT: "+ n);
		notify();
		flag = true;
		
	}
	
	synchronized int get(){
		
		if (!flag) {
			try {
				wait();
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
			
		}
		
		System.out.println("GET: "+n);
		notify();
		flag = false;
		return n;
		
	}

}

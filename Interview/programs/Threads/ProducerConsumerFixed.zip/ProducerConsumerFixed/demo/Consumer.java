package demo;

public class Consumer implements Runnable {
	Inventory inventory;
	public Consumer(Inventory inventory) {
		this.inventory = inventory;	
		new Thread(this, "Consumer").start();;
		
	}

	@Override
	public void run() {
		
		while (true) {
			inventory.get();
		}

	}

}

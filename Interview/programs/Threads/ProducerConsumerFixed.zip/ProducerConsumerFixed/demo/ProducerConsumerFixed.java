package demo;

public class ProducerConsumerFixed {

	public static void main(String[] args) {		
		
		Inventory inventory = new Inventory();
		new Producer(inventory);
		new Consumer(inventory);

	}

}

package demo;

public class Producer implements Runnable {
	Inventory inventory;
	
	public Producer(Inventory inventory) {
		this.inventory = inventory;
		new Thread(this, "Producer").start();
	}

	@Override
	public void run() {
		
		int i = 0;
		while(true){
			inventory.put(++i);
			
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}
		

	}

}

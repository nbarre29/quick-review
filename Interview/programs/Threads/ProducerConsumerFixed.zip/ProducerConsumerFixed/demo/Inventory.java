package demo;

public class Inventory {
	int n;
	boolean flag = false;
	
	synchronized void put(int n){
		if (flag) {
			try {
				wait();
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
			
		}
		this.n = n;
		flag=true;
		System.out.println("Put: "+n);
		notify();
		
	}
	
	synchronized int get(){
		if (!flag) {
			try {
				wait();
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
			
			
		}
		
		System.out.println("Get: "+n);
		flag = false;
		notify();
		return n;
		
	}

}

package com.jsonparser;

import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import java.util.*;

/**
 * Customizable JSON parser where you can specify which keys to extract
 */
public class CustomJsonParser {

    private final ObjectMapper mapper;

    public CustomJsonParser() {
        this.mapper = new ObjectMapper();
    }

    /**
     * Parse JSON and extract specified keys in tab-delimited format
     *
     * @param jsonString The JSON string to parse
     * @param arrayPath Path to the array (e.g., "users", "data.items")
     * @param keyMappings Map of field paths to output column names
     */
    public void parseAndOutput(String jsonString, String arrayPath,
                               LinkedHashMap<String, String> keyMappings) throws Exception {
        JsonNode rootNode = mapper.readTree(jsonString);
        JsonNode arrayNode = navigateToNode(rootNode, arrayPath);

        if (arrayNode == null || !arrayNode.isArray()) {
            throw new IllegalArgumentException("Array not found at path: " + arrayPath);
        }

        // Print header
        System.out.println(String.join("\t", keyMappings.values()));

        // Process each item in array
        for (JsonNode item : arrayNode) {
            List<String> values = new ArrayList<>();

            for (String fieldPath : keyMappings.keySet()) {
                JsonNode valueNode = navigateToNode(item, fieldPath);
                String value = extractValue(valueNode);
                values.add(value);
            }

            System.out.println(String.join("\t", values));
        }
    }

    private JsonNode navigateToNode(JsonNode root, String path) {
        if (path == null || path.isEmpty()) {
            return root;
        }

        String[] parts = path.split("\\.");
        JsonNode current = root;

        for (String part : parts) {
            if (current == null) {
                return null;
            }
            current = current.get(part);
        }

        return current;
    }

    private String extractValue(JsonNode node) {
        if (node == null || node.isNull()) {
            return "";
        }

        if (node.isArray()) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < node.size(); i++) {
                sb.append(node.get(i).asText());
                if (i < node.size() - 1) {
                    sb.append(", ");
                }
            }
            return sb.toString();
        }

        if (node.isObject()) {
            return node.toString();
        }

        return node.asText();
    }

    public static void main(String[] args) {
        String jsonString = """
        {
            "products": [
                {
                    "id": 101,
                    "name": "Laptop",
                    "price": 999.99,
                    "specs": {
                        "cpu": "Intel i7",
                        "ram": "16GB"
                    },
                    "tags": ["electronics", "computers"]
                },
                {
                    "id": 102,
                    "name": "Mouse",
                    "price": 29.99,
                    "specs": {
                        "cpu": null,
                        "ram": null
                    },
                    "tags": ["electronics", "accessories"]
                }
            ]
        }
        """;

        try {
            CustomJsonParser parser = new CustomJsonParser();

            // Define which keys to extract and their column names
            LinkedHashMap<String, String> keyMappings = new LinkedHashMap<>();
            keyMappings.put("id", "Product ID");
            keyMappings.put("name", "Product Name");
            keyMappings.put("price", "Price");
            keyMappings.put("specs.cpu", "CPU");
            keyMappings.put("specs.ram", "RAM");
            keyMappings.put("tags", "Tags");

            parser.parseAndOutput(jsonString, "products", keyMappings);

        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
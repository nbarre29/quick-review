package com.jsonparser;

import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import java.util.*;

public class JsonParser {

    public static void main(String[] args) {
        // Sample complex JSON
        String jsonString = """
        {
            "users": [
                {
                    "id": 1,
                    "name": "John Doe",
                    "email": "john@example.com",
                    "address": {
                        "street": "123 Main St",
                        "city": "New York",
                        "country": "USA"
                    },
                    "roles": ["admin", "user"]
                },
                {
                    "id": 2,
                    "name": "Jane Smith",
                    "email": "jane@example.com",
                    "address": {
                        "street": "456 Oak Ave",
                        "city": "Los Angeles",
                        "country": "USA"
                    },
                    "roles": ["user"]
                }
            ],
            "metadata": {
                "total": 2,
                "timestamp": "2024-01-23T10:00:00Z"
            }
        }
        """;

        try {
            // Parse and output specific keys
            parseAndOutputTabDelimited(jsonString);
        } catch (Exception e) {
            System.err.println("Error parsing JSON: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void parseAndOutputTabDelimited(String jsonString) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        JsonNode rootNode = mapper.readTree(jsonString);

        // Extract users array
        JsonNode usersNode = rootNode.get("users");

        if (usersNode != null && usersNode.isArray()) {
            // Print header
            System.out.println("ID\tName\tEmail\tCity\tCountry\tRoles");

            // Process each user
            for (JsonNode user : usersNode) {
                int id = user.get("id").asInt();
                String name = user.get("name").asText();
                String email = user.get("email").asText();

                // Get nested address fields
                JsonNode address = user.get("address");
                String city = address.get("city").asText();
                String country = address.get("country").asText();

                // Get array of roles
                JsonNode rolesNode = user.get("roles");
                StringBuilder roles = new StringBuilder();
                if (rolesNode.isArray()) {
                    for (int i = 0; i < rolesNode.size(); i++) {
                        roles.append(rolesNode.get(i).asText());
                        if (i < rolesNode.size() - 1) {
                            roles.append(", ");
                        }
                    }
                }

                // Output in tab-delimited format
                System.out.println(id + "\t" + name + "\t" + email + "\t" +
                        city + "\t" + country + "\t" + roles.toString());
            }

            System.out.println("\n--- Copy the output above and paste into Excel ---");
        }
    }

    /**
     * Generic method to extract all key-value pairs from JSON
     * and output in tab-delimited format
     */
    public static void extractAllKeyValues(String jsonString, String targetKey) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        JsonNode rootNode = mapper.readTree(jsonString);

        List<Map<String, String>> results = new ArrayList<>();
        extractKeyValues(rootNode, targetKey, "", results);

        if (!results.isEmpty()) {
            // Get all unique keys for header
            Set<String> allKeys = new LinkedHashSet<>();
            for (Map<String, String> result : results) {
                allKeys.addAll(result.keySet());
            }

            // Print header
            System.out.println(String.join("\t", allKeys));

            // Print rows
            for (Map<String, String> result : results) {
                List<String> values = new ArrayList<>();
                for (String key : allKeys) {
                    values.add(result.getOrDefault(key, ""));
                }
                System.out.println(String.join("\t", values));
            }
        }
    }

    private static void extractKeyValues(JsonNode node, String targetKey,
                                         String path, List<Map<String, String>> results) {
        if (node.isObject()) {
            Iterator<Map.Entry<String, JsonNode>> fields = node.properties().iterator();
            while (fields.hasNext()) {
                Map.Entry<String, JsonNode> field = fields.next();
                String newPath = path.isEmpty() ? field.getKey() : path + "." + field.getKey();
                extractKeyValues(field.getValue(), targetKey, newPath, results);
            }
        } else if (node.isArray()) {
            for (int i = 0; i < node.size(); i++) {
                extractKeyValues(node.get(i), targetKey, path + "[" + i + "]", results);
            }
        } else {
            // Leaf node - add to current result
            Map<String, String> result = new HashMap<>();
            result.put(path, node.asText());
            results.add(result);
        }
    }
}